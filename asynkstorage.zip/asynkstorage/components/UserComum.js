import React, {useState} from 'react'
import { 
  Button,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from 'react-native'


export default function ConfirmationScreen(props) {


  const {nome} = props.route.params;


  return (
    <SafeAreaView>
      <View style={ estilos.page }>

        <Text style={ estilos.input }>Seja Bem Vindo: {nome} </Text>
      
        <Button 
          title="Sair"
          onPress={() => props.navigation.goBack() } />
         
      </View>
    </SafeAreaView>
  )
}

const estilos = StyleSheet.create({
  page : {
    padding : 16
  },
  input : {
    borderColor : '#CCC',
    borderRadius : 5,
    borderWidth : 1,
    height : 40,
    lineHeight : 40,
    padding : 8,
    marginBottom : 8,
    marginHorizontal : 8
  },
})

