import React, {useState} from 'react'
import { 
  Button,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from 'react-native'

import {insertString,insertObject, remove, allKeys,clear} from '../DB'

export default function ConfirmationScreen(props) {

  const {nome} = props.route.params;

  return (
    <SafeAreaView>
      <View style={ estilos.page }>

    
        <Text style={ estilos.input }>Seja Bem Vindo: {nome} </Text>
        
        <Button 
          title="Limpar banco de dados"
          onPress={()=>{
              props.navigation.goBack()
              clear((error =>{
                alert('Banco de dados limpo')
              }))} }/>
          
      
      </View>
    </SafeAreaView>
  )
}

const estilos = StyleSheet.create({
  page : {
    padding : 16
  },
  input : {
    borderColor : '#CCC',
    borderRadius : 5,
    borderWidth : 1,
    height : 40,
    lineHeight : 40,
    padding : 8,
    marginBottom : 8,
    marginHorizontal : 8
  },
})

