import React, {useState} from 'react'
import { 
  Button,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from 'react-native'

import {insertString,insertObject, remove, allKeys,clear} from '../DB'

export default function CadastroScreen(props){

  const [usuario,setUsuario] = useState('')
  const [email, setEmail] = useState('')
  const [senha, setSenha] = useState('')
  const [confirmar, setConfirmar] = useState('')


return(
  <SafeAreaView>
    <TextInput  
        onChangeText={ (txt) => setUsuario(txt) }
        placeholder="Usuário"
        style={ estilos.input }/>

    <TextInput  
        onChangeText={ (txt) => setEmail(txt) }
        placeholder="E-mail"
        style={ estilos.input }/>

    <TextInput 
        onChangeText={ (txt) => setSenha(txt) }
        placeholder="Senha"
        style={ estilos.input } />

    <TextInput 
        onChangeText={ (txt) => setConfirmar(txt) }
        placeholder="Confirmar senha"
        style={ estilos.input } />

    
    <Button 
          title="Salvar"
          onPress={() => {
            if (senha === confirmar){
                insertString('Usuario', usuario)
                insertString('Email',email)
                insertString('Senha',senha)
                insertString('Confirmar',confirmar)
                alert('Dados Salvos com sucesso')
            } else{
              alert ('Senha e Confirmação de Senha Divergem')
            }
          } } />

    <Button 
          title="Cancelar"
          onPress={() => props.navigation.goBack() } />

  </SafeAreaView>

)
}

const estilos = StyleSheet.create({
  input : {
    borderColor : '#CCC',
    borderRadius : 5,
    borderWidth : 1,
    height : 40,
    lineHeight : 40,
    padding : 8,
    marginBottom : 8,
    marginHorizontal : 8
  },
})








