import React, {useState} from 'react'
import { 
  Button,
  SafeAreaView,
  Text,
  TextInput,
  StyleSheet
} from 'react-native'

export default function HomeScreen(props) {

  const [nome,setNome] = useState('')
  const [senha, setSenha] = useState('')
 

  return (
    <SafeAreaView>

      <TextInput  
        onChangeText={ (txt) => setNome(txt) }
        placeholder="Nome"
        style={ estilos.input }/>

      <TextInput 
        onChangeText={ (txt) => setSenha(txt) }
        placeholder="Senha"
        style={ estilos.input } />

     <Button 
          title="Realizar Login"
          onPress={()=> { 
            if (senha === "fiap" & nome==='fiap'){
              props.navigation.navigate('Confirmação', {nome})
            } else {
              alert('Usuario e senha invalidos');
            }  
            }} />

    </SafeAreaView>
  )
}

const estilos = StyleSheet.create({
  input : {
    borderColor : '#CCC',
    borderRadius : 5,
    borderWidth : 1,
    height : 40,
    lineHeight : 40,
    padding : 8,
    marginBottom : 8,
    marginHorizontal : 8
  }
})